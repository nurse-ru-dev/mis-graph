const API = "https://script.google.com/macros/s/AKfycbwjVL_hoCe_qucVpftJjU-f01vevdwh8QnJQrl5TinYXXlMaf5rVOK5Ylr1L8yAidcnsg/exec";

let chart1 = null;
let chart2 = null;
let chart3 = null;
let latestData = null;

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("courseSearch").addEventListener("input", renderTableFromLatest);
  loadData();
});

async function loadData() {
  try {
    showMessage("กำลังโหลดข้อมูลจากตาราง 2569...", false);
    const res = await fetch(API);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (data.ok === false) throw new Error(data.error || "Backend error");
    latestData = data;
    render(data);
    hideMessage();
  } catch (error) {
    console.error(error);
    showMessage("โหลดข้อมูลไม่สำเร็จ กรุณาตรวจสอบ API_URL และการ Deploy Web App", true);
  }
}

function render(data) {
  setText("totalFtes", formatNumber(data.summary.totalFtes));
  setText("actualTeachers", formatNumber(data.summary.actualTeachers));
  setText("actualTeacherRatio", data.summary.actualTeacherRatio || "-");
  setText("requiredTeachers", formatNumber(data.summary.requiredTeachers));
  setText("requiredTeacherRatio", data.summary.requiredTeacherRatio || "-");
  setText("teacherRuleText", data.summary.teacherRuleText || "-");
  renderTableFromLatest();
  renderCharts(data);
}

function renderTableFromLatest() {
  if (!latestData) return;
  const keyword = (document.getElementById("courseSearch").value || "").trim().toLowerCase();
  const tbody = document.getElementById("tableBody");
  const rows = (latestData.courses || []).filter(c => {
    if (!keyword) return true;
    return String(c.courseName || "").toLowerCase().includes(keyword)
      || String(c.studyYear || "").toLowerCase().includes(keyword)
      || String(c.semester || "").toLowerCase().includes(keyword);
  });

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280">ไม่พบข้อมูล</td></tr>';
    return;
  }

  tbody.innerHTML = rows.map(c => `
    <tr>
      <td>${escapeHtml(c.courseName || "-")}</td>
      <td>${escapeHtml(c.studyYear || "-")}</td>
      <td>${escapeHtml(c.semester || "-")}</td>
      <td>${formatNumber(c.sch)}</td>
      <td>${formatNumber(c.ftes)}</td>
    </tr>
  `).join("");
}

function renderCharts(data) {
  if (chart1) chart1.destroy();
  if (chart2) chart2.destroy();
  if (chart3) chart3.destroy();

  chart1 = new Chart(document.getElementById("ftesByYearChart"), {
    type: "bar",
    data: {
      labels: data.ftesByYear.labels,
      datasets: [{ label: "FTES", data: data.ftesByYear.values }]
    },
    options: getChartOptions(false)
  });

  chart2 = new Chart(document.getElementById("teacherByYearChart"), {
    type: "bar",
    data: {
      labels: data.teacherByYear.labels,
      datasets: [{ label: "จำนวนอาจารย์", data: data.teacherByYear.values }]
    },
    options: getChartOptions(false)
  });

  chart3 = new Chart(document.getElementById("ratioByYearChart"), {
    type: "bar",
    data: {
      labels: data.ratioByYear.labels,
      datasets: [{ label: "FTES ต่ออาจารย์ 1 คน", data: data.ratioByYear.values }]
    },
    options: getChartOptions(false)
  });
}

function getChartOptions(horizontal) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: horizontal ? "y" : "x",
    plugins: { legend: { display: true } },
    scales: {
      x: { beginAtZero: true },
      y: { beginAtZero: true }
    }
  };
}

function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function formatNumber(value) {
  const num = Number(value || 0);
  return num.toLocaleString("th-TH", {
    minimumFractionDigits: num % 1 !== 0 ? 2 : 0,
    maximumFractionDigits: 2
  });
}

function showMessage(text, persist = false) {
  const box = document.getElementById("messageBox");
  box.textContent = text;
  box.classList.remove("hidden");
  if (!persist) {
    setTimeout(() => { if (box.textContent === text) hideMessage(); }, 1500);
  }
}

function hideMessage() {
  document.getElementById("messageBox").classList.add("hidden");
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
