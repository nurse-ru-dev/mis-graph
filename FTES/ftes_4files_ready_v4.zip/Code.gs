const SPREADSHEET_ID = '19uDHafBByN5jRyJUstDF0GgXLAXZDol_Uj094hJY00c';
const TARGET_SHEET_NAME = '2569';
const ACTUAL_TEACHERS = 31; // ปี 1 และ ปี 2 (เมษายน 2569)
const PROJECTED_TEACHERS = {
  'ปี 3': 38,
  'ปี 4': 50
};

function doGet() {
  try {
    const result = buildDashboardData_();
    return ContentService.createTextOutput(JSON.stringify(result))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false,
      error: err.message,
      stack: err.stack
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function buildDashboardData_() {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(TARGET_SHEET_NAME);
  if (!sheet) throw new Error('ไม่พบชีต 2569');

  const parsed = parseFtesSheet_(sheet);
  const rows = parsed.rows || [];

  const totalFtes = sum_(rows.map(r => r.ftes));
  const actualTeachers = ACTUAL_TEACHERS;
  const actualTeacherRatio = actualTeachers > 0 ? `1 : ${round2_(totalFtes / actualTeachers)}` : '-';

  const requiredTeachers = getRequiredTeachersFromRows_(rows);
  const requiredTeacherRatio = requiredTeachers > 0 ? `1 : ${round2_(totalFtes / requiredTeachers)}` : '-';

  const ftesByYearMap = {};
  rows.forEach(r => {
    ftesByYearMap[r.studyYear] = (ftesByYearMap[r.studyYear] || 0) + r.ftes;
  });

  const orderedYears = sortStudyYears_(Object.keys(ftesByYearMap));
  const ftesByYearValues = orderedYears.map(y => round2_(ftesByYearMap[y]));
  const teacherByYearValues = orderedYears.map(y => getTeacherCountByStudyYear_(y));
  const ratioByYearValues = orderedYears.map(y => {
    const teachers = getTeacherCountByStudyYear_(y);
    const ftes = ftesByYearMap[y] || 0;
    return teachers > 0 ? round2_(ftes / teachers) : 0;
  });

  return {
    ok: true,
    summary: {
      totalFtes: round2_(totalFtes),
      actualTeachers: actualTeachers,
      actualTeacherRatio: actualTeacherRatio,
      requiredTeachers: requiredTeachers,
      requiredTeacherRatio: requiredTeacherRatio,
      teacherRuleText: 'ปี 1–2 ใช้อาจารย์จริง 31 คน (เมษายน 2569), ปี 3 ใช้ 38 คน, ปี 4 ใช้ 50 คน'
    },
    ftesByYear: {
      labels: orderedYears,
      values: ftesByYearValues
    },
    teacherByYear: {
      labels: orderedYears,
      values: teacherByYearValues
    },
    ratioByYear: {
      labels: orderedYears,
      values: ratioByYearValues
    },
    courses: rows.map(r => ({
      courseName: r.courseName || '',
      studyYear: r.studyYear || '',
      semester: r.semester || '',
      sch: round2_(r.sch || 0),
      ftes: round2_(r.ftes || 0)
    }))
  };
}

function getRequiredTeachersFromRows_(rows) {
  const yearSet = {};
  rows.forEach(r => {
    yearSet[r.studyYear] = true;
  });
  const years = Object.keys(yearSet);
  return years.reduce((sum, year) => sum + getTeacherCountByStudyYear_(year), 0);
}

function getTeacherCountByStudyYear_(studyYear) {
  if (studyYear === 'ปี 1' || studyYear === 'ปี 2') return ACTUAL_TEACHERS;
  if (PROJECTED_TEACHERS[studyYear]) return PROJECTED_TEACHERS[studyYear];
  return 0;
}

function parseFtesSheet_(sheet) {
  const values = sheet.getDataRange().getDisplayValues();
  if (!values || values.length < 5) return { rows: [] };

  let currentProgram = 'พยาบาลศาสตร์';
  let currentStudyYear = '';
  let currentSemester = '';
  const rows = [];

  for (let i = 0; i < values.length; i++) {
    const row = values[i];
    const colA = safeTrim_(row[0]);
    const colB = safeTrim_(row[1]);
    const colD = safeTrim_(row[3]);
    const colE = safeTrim_(row[4]);
    const colF = safeTrim_(row[5]);
    const colG = safeTrim_(row[6]);
    const colI = safeTrim_(row[8]);
    const colJ = safeTrim_(row[9]);

    if (colB === 'พยาบาลศาสตร์' || colB === 'พยาบาลศาสตร์บัณฑิต') {
      currentProgram = colB;
      continue;
    }

    if (/^ชั้นปีที่\s*\d+/.test(colB)) {
      currentStudyYear = normalizeStudyYear_(colB);
      continue;
    }

    if (/^ภาคการศึกษาที่\s*\d+/.test(colB)) {
      currentSemester = normalizeSemester_(colB);
      continue;
    }

    if (!colE) continue;
    if (colE === 'รายวิชา') continue;
    if (/^รวม/.test(colA) || /^รวม/.test(colB)) continue;

    const creditNumeric = toNumber_(colF);
    const teachingHours = toNumber_(colG);
    const sch = toNumber_(colI);
    const ftes = toNumber_(colJ);

    if (!creditNumeric && !teachingHours && !sch && !ftes) continue;

    rows.push({
      programName: currentProgram,
      studyYear: currentStudyYear,
      semester: currentSemester,
      courseName: colE,
      creditText: colD,
      creditNumeric: creditNumeric,
      teachingHours: teachingHours,
      sch: sch,
      ftes: ftes
    });
  }

  return { rows: rows };
}

function normalizeStudyYear_(text) {
  const match = String(text).match(/ชั้นปีที่\s*(\d+)/);
  return match ? `ปี ${match[1]}` : text;
}

function normalizeSemester_(text) {
  const match = String(text).match(/ภาคการศึกษาที่\s*(\d+)/);
  return match ? `ภาค ${match[1]}` : text;
}

function toNumber_(value) {
  if (value === '' || value == null) return 0;
  const cleaned = String(value).replace(/,/g, '').trim();
  const num = Number(cleaned);
  return isNaN(num) ? 0 : num;
}

function safeTrim_(value) {
  return value == null ? '' : String(value).trim();
}

function sum_(arr) {
  return arr.reduce((sum, n) => sum + (Number(n) || 0), 0);
}

function round2_(n) {
  return Math.round((Number(n) || 0) * 100) / 100;
}

function sortStudyYears_(years) {
  return years.sort((a, b) => {
    const na = Number(String(a).replace(/[^\d]/g, '')) || 0;
    const nb = Number(String(b).replace(/[^\d]/g, '')) || 0;
    return na - nb;
  });
}
